import React from "react";

const RestaurantPanel = () => {
  return <div>RestaurantPanel</div>;
};

export default RestaurantPanel;
