import { useState } from "react";
import { Link } from "react-router-dom";
import PropTypes from "prop-types";
import { sidebarItems } from "../../Utils/data";

const Sidebar = ({ isSidebarOpen }) => {
  const [hoveredItem, setHoveredItem] = useState(null);
  const [openSection, setOpenSection] = useState(null);

  const toggleSection = (index) => {
    setOpenSection((prevSection) => (prevSection === index ? null : index));
  };



  return (
    <div className=" ">
      <div className={`fixed ${isSidebarOpen ? "w-52" : "w-16"} `}>
      <img src="/logo-e.png" alt="Logo" className="w-16 mx-auto" />
      </div>
      <div className="fixed mt-16 flex flex-col bg-primary-900 h-screen text-white transition-all duration-300 ease-in-out overflow-y-auto">
        {sidebarItems.map((section, index) => (
          <div key={index}>
            <div
              className="relative flex items-center hover:bg-primary-100 hover:text-primary-900"
              onMouseEnter={() => setHoveredItem(index)}
              onMouseLeave={() => setHoveredItem(null)}
            >
              <Link to={section.path}>
                <div
                  onClick={() => toggleSection(index)}
                  className={`relative flex items-center justify-center h-14 w-full`}
                >
                  <div className="w-16 flex justify-center items-center text-lg">
                    {section.icon}
                  </div>
                  {(isSidebarOpen || hoveredItem === index) && (
                    <div
                      className={`p-2 h-16 items-center text-sm flex text-left transition-all duration-300 ease-in-out ${
                        isSidebarOpen ? "w-36" : "w-52"
                      }`}
                    >
                      {section.title}
                    </div>
                  )}
                </div>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

Sidebar.propTypes = {
  isSidebarOpen: PropTypes.bool.isRequired,
};

export default Sidebar;
