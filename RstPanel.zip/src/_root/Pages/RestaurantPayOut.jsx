import React, { useState } from "react";
import MainCard from "../../AllCards/DashboardCards/MainCard";
import DataTableInfo from "../../AllCards/DashboardCards/DataTableInfo";
import HeadingCard from "../../AllCards/HeadingCard";

import { FaTrashAlt } from "react-icons/fa";
import { TbTriangleFilled, TbTriangleInvertedFilled } from "react-icons/tb";
import { MdAdd, MdModeEdit } from "react-icons/md";
import { TfiMenuAlt } from "react-icons/tfi";
import { Link } from "react-router-dom";
import CardHeader from "../../AllCards/CardHeader";
import RstHeadingCard from "../../components/RstCards/RstHeadingCard";

const initialRoles = [
  {
    date: "Sun jan 2024 12:34:00 Pm",
    note: "from App",
    adminnote: "From Admin",
    paidamount: "($23)",
    name: "Super Administrator",
  },
  {
    date: "Sun jan 2024 12:34:00 Pm",
    note: "from App",
    adminnote: "From Admin",
    paidamount: "($23)",
    name: "Administrator",
  },
  {
    date: "Sun jan 2024 12:34:00 Pm",
    note: "from App",
    adminnote: "From Admin",
    paidamount: "($23)",
    name: "User",
  },
  {
    date: "Sun jan 2024 12:34:00 Pm",
    note: "from App",
    adminnote: "From Admin",
    paidamount: "($23)",
    name: "Super Administrator",
  },
  {
    date: "Sun jan 2024 12:34:00 Pm",
    note: "from App",
    adminnote: "From Admin",
    paidamount: "($23)",
    name: "Administrator",
  },
  {
    date: "Sun jan 2024 12:34:00 Pm",
    note: "from App",
    adminnote: "From Admin",
    paidamount: "($23)",
    name: "User",
  },
  {
    date: "Sun jan 2024 12:34:00 Pm",
    note: "from App",
    adminnote: "From Admin",
    paidamount: "($23)",
    name: "Super Administrator",
  },
  {
    date: "Sun jan 2024 12:34:00 Pm",
    note: "from App",
    adminnote: "From Admin",
    paidamount: "($23)",
    name: "Administrator",
  },
  {
    date: "Sun jan 2024 12:34:00 Pm",
    note: "from App",
    adminnote: "From Admin",
    paidamount: "($23)",
    name: "User",
  },
  {
    date: "Sun jan 2024 12:34:00 Pm",
    note: "from App",
    adminnote: "From Admin",
    paidamount: "($23)",
    name: "Super Administrator",
  },
  {
    date: "Sun jan 2024 12:34:00 Pm",
    note: "from App",
    adminnote: "From Admin",
    paidamount: "($23)",
    name: "Administrator",
  },
  {
    date: "Sun jan 2024 12:34:00 Pm",
    note: "from App",
    adminnote: "From Admin",
    paidamount: "($23)",
    name: "User",
  },
]; // Example roles

const RestaurantPayOut = () => {
  const [roles, setRoles] = useState(initialRoles);
  const [sortColumn, setSortColumn] = useState("name");
  const [sortDirection, setSortDirection] = useState("asc");
  const [currentPage, setCurrentPage] = useState(0);
  const [selectedRoles, setSelectedRoles] = useState(new Set());
  const rolesPerPage = 5;

  const handleSort = () => {
    const newDirection = sortDirection === "asc" ? "desc" : "asc";
    const sortedRoles = [...roles].sort((a, b) => {
      if (a.name < b.name) return newDirection === "asc" ? -1 : 1;
      if (a.name > b.name) return newDirection === "asc" ? 1 : -1;
      return 0;
    });
    setRoles(sortedRoles);
    setSortDirection(newDirection);
    setSortColumn("name");
  };
  const handlepaidamount = () => {
    const newDirection = sortDirection === "asc" ? "desc" : "asc";
    const sortedRoles = [...roles].sort((a, b) => {
      if (a.name < b.name) return newDirection === "asc" ? -1 : 1;
      if (a.name > b.name) return newDirection === "asc" ? 1 : -1;
      return 0;
    });
    setRoles(sortedRoles);
    setSortDirection(newDirection);
    setSortColumn("paidamount");
  };
  const handledate = () => {
    const newDirection = sortDirection === "asc" ? "desc" : "asc";
    const sortedRoles = [...roles].sort((a, b) => {
      if (a.name < b.name) return newDirection === "asc" ? -1 : 1;
      if (a.name > b.name) return newDirection === "asc" ? 1 : -1;
      return 0;
    });
    setRoles(sortedRoles);
    setSortDirection(newDirection);
    setSortColumn("date");
  };
  const handlenote = () => {
    const newDirection = sortDirection === "asc" ? "desc" : "asc";
    const sortedRoles = [...roles].sort((a, b) => {
      if (a.name < b.name) return newDirection === "asc" ? -1 : 1;
      if (a.name > b.name) return newDirection === "asc" ? 1 : -1;
      return 0;
    });
    setRoles(sortedRoles);
    setSortDirection(newDirection);
    setSortColumn("note");
  };
  const handleadminnote = () => {
    const newDirection = sortDirection === "asc" ? "desc" : "asc";
    const sortedRoles = [...roles].sort((a, b) => {
      if (a.name < b.name) return newDirection === "asc" ? -1 : 1;
      if (a.name > b.name) return newDirection === "asc" ? 1 : -1;
      return 0;
    });
    setRoles(sortedRoles);
    setSortDirection(newDirection);
    setSortColumn("adminnote");
  };

  const startIndex = currentPage * rolesPerPage;
  const displayedRoles = roles.slice(startIndex, startIndex + rolesPerPage);

  return (
    <div className="mx-5 my-3 shadow-md hover:shadow-lg">
      <CardHeader
        createlink={"/restaurantdetailes"}
        createmenu={"Create Restaurants Payout"}
        listmenu={"Restaurants Payouts List"}
      />

      <RstHeadingCard />
      <div className="overflow-x-auto scrollbar-custom">
        <table className="min-w-full bg-white">
          <thead>
            <tr>
              <th className="px-4 py-2 border text-left">
                <button
                  onClick={handleSort}
                  className="flex items-center justify-between w-full gap-1"
                >
                  <h1> Restaurant </h1>
                  <div className="flex flex-col">
                    <TbTriangleFilled
                      className={`transition-colors text-xs ${
                        sortColumn === "name" && sortDirection === "asc"
                          ? "text-gray-500"
                          : "text-gray-300"
                      }`}
                    />
                    <TbTriangleInvertedFilled
                      className={`transition-colors text-xs ${
                        sortColumn === "name" && sortDirection === "desc"
                          ? "text-gray-500"
                          : "text-gray-300"
                      }`}
                    />
                  </div>
                </button>
              </th>

              <th className="px-4 py-2 border text-left">
                <button
                  onClick={handlepaidamount}
                  className="flex items-center justify-between w-full gap-1"
                >
                  <h1>Paid Amount</h1>
                  <div className="flex flex-col">
                    <TbTriangleFilled
                      className={`transition-colors text-xs ${
                        sortColumn === "paidamount" && sortDirection === "asc"
                          ? "text-gray-500"
                          : "text-gray-300"
                      }`}
                    />
                    <TbTriangleInvertedFilled
                      className={`transition-colors text-xs ${
                        sortColumn === "paidamount" && sortDirection === "desc"
                          ? "text-gray-500"
                          : "text-gray-300"
                      }`}
                    />
                  </div>
                </button>
              </th>
              <th className="px-4 py-2 border text-left">
                <button
                  onClick={handledate}
                  className="flex items-center justify-between w-full gap-1"
                >
                  <h1> Date</h1>
                  <div className="flex flex-col">
                    <TbTriangleFilled
                      className={`transition-colors text-xs ${
                        sortColumn === "date" && sortDirection === "asc"
                          ? "text-gray-500"
                          : "text-gray-300"
                      }`}
                    />
                    <TbTriangleInvertedFilled
                      className={`transition-colors text-xs ${
                        sortColumn === "date" && sortDirection === "desc"
                          ? "text-gray-500"
                          : "text-gray-300"
                      }`}
                    />
                  </div>
                </button>
              </th>
              <th className="px-4 py-2 border text-left">
                <button
                  onClick={handlenote}
                  className="flex items-center justify-between w-full gap-1"
                >
                  <h1> Note</h1>
                  <div className="flex flex-col">
                    <TbTriangleFilled
                      className={`transition-colors text-xs ${
                        sortColumn === "note" && sortDirection === "asc"
                          ? "text-gray-500"
                          : "text-gray-300"
                      }`}
                    />
                    <TbTriangleInvertedFilled
                      className={`transition-colors text-xs ${
                        sortColumn === "note" && sortDirection === "desc"
                          ? "text-gray-500"
                          : "text-gray-300"
                      }`}
                    />
                  </div>
                </button>
              </th>
              <th className="px-4 py-2 border text-left">
                <button
                  onClick={handleadminnote}
                  className="flex items-center justify-between w-full gap-1"
                >
                  <h1> Admin Note</h1>
                  <div className="flex flex-col">
                    <TbTriangleFilled
                      className={`transition-colors text-xs ${
                        sortColumn === "adminnote" && sortDirection === "asc"
                          ? "text-gray-500"
                          : "text-gray-300"
                      }`}
                    />
                    <TbTriangleInvertedFilled
                      className={`transition-colors text-xs ${
                        sortColumn === "adminnote" && sortDirection === "desc"
                          ? "text-gray-500"
                          : "text-gray-300"
                      }`}
                    />
                  </div>
                </button>
              </th>
              {/* <th className="px-4 py-2 border text-left bg-[#F8FAFD]">
                Status
              </th> */}
            </tr>
          </thead>
          <tbody>
            {displayedRoles.map((role, index) => (
              <tr key={index} className="hover:bg-gray-200">
                <td className="px-4 py-2 border text-left text-red1 text-sm">
                  {role.name}
                </td>
                <td className="px-4 py-2 border text-left text-red1 text-sm">
                  {role.paidamount}
                </td>
                <td className="px-4 py-2 border text-left text-gray-400 text-sm">
                  {role.date}
                </td>
                <td className="px-4 py-2 border text-left text-gray-400 text-sm">
                  {role.note}
                </td>
                <td className="px-4 py-2 border text-left text-gray-400 text-sm">
                  {role.adminnote}
                  {/* <button>
                    <MdModeEdit className="p-1 bg-green1 text-[1.6rem] rounded-full text-white" />
                  </button> */}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <DataTableInfo entries={roles.length} totalentries={roles.length} />
    </div>
  );
};

export default RestaurantPayOut;
